export class UserModel {

	public name:String;
	public password:String;
	public userPicture:String;

	constructor(){}
}
