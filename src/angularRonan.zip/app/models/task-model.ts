export class TaskModel {

	public name: String;
	public isDone: Boolean;

	constructor(taskName: String) {
		this.name = taskName;
		this.isDone = false;
	}
}
