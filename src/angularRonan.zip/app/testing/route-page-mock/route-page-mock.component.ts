import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'route-page-mock',
  templateUrl: './route-page-mock.component.html',
  styleUrls: ['./route-page-mock.component.css']
})
export class RoutePageMockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
