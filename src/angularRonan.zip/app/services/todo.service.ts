import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

//Class
import {TodoModel} from '../models/todo-model';
import {TaskModel} from '../models/task-model';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

	todoList : TodoModel[]=[];
	todoListSubject = new Subject<TodoModel[]>();

  todoSelectedIndex : number;
  todoSelectedSubject = new Subject<TodoModel>();

  constructor() { }

  createTodo(todoModel:TodoModel)
  {
  	this.todoList.push(todoModel);
  	this.emitTodoListSubject();
  }

  deleteTodo(index:number)
  {
    this.todoList.splice(index,1);
    this.emitTodoListSubject();
  }

  updateTodo(updatedTodo:TodoModel, index:number)
  {
    this.todoList[index]=updatedTodo;
    this.emitTodoListSubject();
  }

  selectTodo(index:number)
  {
    this.todoSelectedIndex=index;
    this.emitTodoSelectedSubject();
  }

  updateTask(task:TaskModel, taskIndex:number)
  {
    this.todoList[this.todoSelectedIndex].tasks[taskIndex] = task;
    this.emitTodoSelectedSubject();
  }

  deleteTask(taskIndex:number)
  {
    this.todoList[this.todoSelectedIndex].tasks.splice(taskIndex,1);
    this.emitTodoSelectedSubject();
  }

  createTask(task:TaskModel)
  {
    this.todoList[this.todoSelectedIndex].tasks.push(task);
    this.emitTodoSelectedSubject();
  }

  emitTodoListSubject() {
    this.todoListSubject.next(this.todoList.slice());
  }

  emitTodoSelectedSubject() {
    this.todoSelectedSubject.next(this.todoList[this.todoSelectedIndex]);
  }
}
