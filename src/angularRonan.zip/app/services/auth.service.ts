import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { NgForm } from '@angular/forms'

//Class
import { UserModel } from '../models/user-model';

@Injectable()
export class AuthService {

  public connectedUser: UserModel;
  public authStatus: boolean;
  public connectedUserSubject = new Subject<UserModel>();
  public authStatusSubject = new Subject<boolean>();


  // id/password bouchon
  public idBouchon: string = "Bouchon";
  public passwordBouchon: string = "Bouchon";


  constructor() {
    this.authStatus=false;
    this.connectedUser = new UserModel();
  }

  checkAuthentification(userModel: UserModel) {
    if (this.idBouchon === userModel.name && this.passwordBouchon === userModel.password) {
      userModel.userPicture = "../../assets/userBouchonPicture.png";
      this.authStatus = true;
      this.connectedUser = userModel;
      this.emitAuthStatusSubject();
      this.emitConnectedUserSubject();
    }
    return this.authStatus;
  }

  checkAlreadyLogged() {
    return this.authStatus;
  }

  createNewAccount(form: NgForm) {

    /*var newAccount =
    {
      user: form.value['user'],
      password: form.value['password']
    };
    console.log(newAccount);
    this.httpClient
      .post('http://localhost:8080/api/user', newAccount)
      .subscribe(
        () => {
          console.log('Enregistrement terminé !');
        },
        (error) => {
          console.log('Erreur ! : ' + error);
        }
      );*/
  }

  logout() {
    this.authStatus = false;
    this.connectedUser = new UserModel();
    this.emitAuthStatusSubject();
    this.emitConnectedUserSubject();
  }

  emitAuthStatusSubject() {
    this.authStatusSubject.next(this.authStatus);
  }

  emitConnectedUserSubject() {
    this.connectedUserSubject.next(this.connectedUser);
  }

}
